# Production Deployment Checklist

## ✅ Pre-Deployment Fixes Completed

### Blog URLs Fixed
- ✅ Updated all canonical URLs to clean format (`/blog/slug` instead of `/blog/post.php?slug=`)
- ✅ Fixed internal blog links in content
- ✅ All 5 blog posts now use clean URLs

### Homepage Enhanced
- ✅ Added gallery showcase section with 6 example images
- ✅ Images responsive and properly styled

### htaccess Fixed
- ✅ Blog clean URL rewriting working
- ✅ HTTPS redirect commented out for local dev (needs uncommenting on production)

---

## 🚨 CRITICAL - Before Uploading

### 1. Configuration File
**DO NOT upload config.php to production!**

On production server:
```bash
# Copy the example config
cp config.example.php config.php

# Edit with production values
nano config.php
```

Update these values in production config.php:
- `DB_HOST` - Your production database host
- `DB_NAME` - Your production database name
- `DB_USER` - Your production database user
- `DB_PASS` - Your production database password
- `FAL_API_KEY` - Your FAL API key: **$87cf2868-c4b7-4e77-844a-9e239c498006:fe874f3b8d532fa90bd139a0b106aaa1**
- `SITE_URL` - Change from localhost to `https://free-ai-generator.com`
- `GOOGLE_ANALYTICS_ID` - Add your Google Analytics tracking ID (if you have one)

### 2. Enable HTTPS Redirect
In `.htaccess` on production, uncomment lines 15-17:
```apache
RewriteCond %{HTTPS} off
RewriteCond %{HTTP_HOST} !^localhost [NC]
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 3. Database Setup
Import the database schema (you'll need to create/export database.sql):
```sql
CREATE DATABASE your_production_db;
USE your_production_db;
source database.sql;
```

**Database Tables Needed:**
- `generations` - stores generation records
- `ip_usage` - tracks IP rate limiting

### 4. File Permissions
```bash
# Set correct permissions
find . -type f -exec chmod 644 {} \;
find . -type d -exec chmod 755 {} \;

# Make config.php more restrictive
chmod 600 config.php

# Ensure gallery directory is writable (if needed)
chmod 755 assets/img/gallery/
```

### 5. Apache Configuration
Ensure these Apache modules are enabled:
```bash
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod deflate
sudo a2enmod expires
sudo systemctl restart apache2
```

### 6. Directory Structure Check
Ensure these directories exist:
- ✅ `/api/` - API endpoints
- ✅ `/assets/css/` - Stylesheets
- ✅ `/assets/js/` - JavaScript files
- ✅ `/assets/img/gallery/` - Gallery images (12 images present)
- ✅ `/blog/` - Blog directory
- ✅ `/blog/posts/` - 5 blog posts
- ✅ `/includes/` - Header and footer

---

## 📋 Files to Upload

### Core Files (Upload)
- ✅ `index.php` - Homepage
- ✅ `gallery.php` - Gallery page
- ✅ `.htaccess` - URL rewriting & security
- ✅ `robots.txt` - SEO crawler instructions
- ✅ `sitemap.xml` - SEO sitemap
- ✅ `config.example.php` - Config template
- ✅ `db.php` - Database models
- ✅ `fal_service.php` - FAL API service

### Directories to Upload
- ✅ `/api/` - All API endpoints
- ✅ `/assets/` - All CSS, JS, images
- ✅ `/blog/` - All blog files and posts
- ✅ `/includes/` - Header and footer

### Documentation (Optional)
- ✅ `README.md`
- ✅ `GIT_SETUP.md`
- ✅ `DIRECTORY_SUBMISSIONS.md`
- ✅ `PRODUCTION_CHECKLIST.md` (this file)

### Files to NEVER Upload
- ❌ `config.php` - Contains secrets! (in .gitignore)
- ❌ `.git/` - Git repository
- ❌ `*.sql` - Database dumps
- ❌ `*.log` - Log files
- ❌ `.env` - Environment variables

---

## 🔒 Security Checklist

- ✅ config.php in .gitignore
- ✅ Sensitive files protected in .htaccess (config.php, db.php, .env)
- ✅ SQL injection prevention (PDO prepared statements)
- ✅ XSS protection (htmlspecialchars on all outputs)
- ✅ CSRF token protection on forms
- ✅ Rate limiting by IP address
- ✅ Directory browsing disabled
- ✅ Security headers configured

**Verify on production:**
```bash
# These files should return 403 Forbidden:
curl https://free-ai-generator.com/config.php
curl https://free-ai-generator.com/db.php
curl https://free-ai-generator.com/.htaccess
```

---

## 🔍 SEO Checklist

- ✅ Clean blog URLs (`/blog/slug`)
- ✅ Canonical URLs set correctly
- ✅ Meta titles and descriptions on all pages
- ✅ Open Graph tags
- ✅ Twitter Cards
- ✅ sitemap.xml with all URLs
- ✅ robots.txt configured
- ✅ Schema.org structured data
- ✅ Google Analytics integration (if ID provided)

**Post-deployment SEO tasks:**
1. Submit sitemap to Google Search Console
2. Submit sitemap to Bing Webmaster Tools
3. Test clean URLs work
4. Check meta tags with Facebook Debugger
5. Verify structured data with Google Rich Results Test

---

## 🧪 Testing Checklist

Test these URLs after deployment:

### Homepage
- [ ] https://free-ai-generator.com/ - loads correctly
- [ ] Generator form visible
- [ ] Gallery showcase images load

### Blog
- [ ] https://free-ai-generator.com/blog/ - blog index loads
- [ ] https://free-ai-generator.com/blog/how-to-generate-free-ai-anime-images - clean URL works
- [ ] https://free-ai-generator.com/blog/flux-ai-model-guide-fast-and-free - clean URL works
- [ ] https://free-ai-generator.com/blog/10-best-use-cases-free-ai-anime-generators - clean URL works
- [ ] https://free-ai-generator.com/blog/free-ai-anime-generator-vs-midjourney - clean URL works
- [ ] https://free-ai-generator.com/blog/commercial-use-guide-ai-anime-images - clean URL works
- [ ] All images in blog posts load correctly

### Gallery
- [ ] https://free-ai-generator.com/gallery.php - loads all 12 images

### API (requires logged-in testing)
- [ ] Generate image test
- [ ] Status check test
- [ ] Rate limiting works (after 3 generations)

### Navigation
- [ ] All navigation links work
- [ ] Footer links work
- [ ] Internal blog links work

### Mobile
- [ ] Test on mobile device
- [ ] Responsive design works
- [ ] Images scale properly

---

## 📊 Performance

- ✅ Gzip compression enabled
- ✅ Browser caching configured (1 year for images, 1 month for CSS/JS)
- ✅ Images optimized
- ✅ CSS/JS minification (consider for future)

**Post-deployment performance checks:**
- Run Google PageSpeed Insights
- Target: 90+ on mobile and desktop

---

## 🎯 Post-Deployment Tasks

### Immediate
1. [ ] Test image generation works
2. [ ] Check error logs for any issues
3. [ ] Verify HTTPS works and redirects properly
4. [ ] Test contact form (if applicable)

### Within 24 Hours
1. [ ] Submit sitemap to Google Search Console
2. [ ] Add site to Bing Webmaster Tools
3. [ ] Set up uptime monitoring (UptimeRobot, Pingdom)
4. [ ] Configure automated backups

### Within 1 Week
1. [ ] Start Month 1 growth plan (see DIRECTORY_SUBMISSIONS.md)
2. [ ] Submit to AI tool directories
3. [ ] Create social media accounts
4. [ ] Write first Reddit posts

---

## 🚀 Deployment Commands

### Via FTP/SFTP
Upload all files except:
- config.php
- .git/
- *.sql
- *.log

### Via Git (Recommended)
```bash
# On production server
cd /var/www/html
git clone https://github.com/YOUR_USERNAME/free-ai-generator.git .

# Setup config
cp config.example.php config.php
nano config.php  # Add production values

# Set permissions
chmod 644 config.php
chmod 755 assets/img/gallery/

# Uncomment HTTPS redirect in .htaccess
```

---

## 📞 Support & Resources

- **FAL.ai API Dashboard:** https://fal.ai/dashboard
- **Google Analytics:** https://analytics.google.com
- **Google Search Console:** https://search.google.com/search-console
- **Apache Docs:** https://httpd.apache.org/docs/

---

## ✅ Final Verification

Before going live, confirm:

1. [ ] Database connected and tables created
2. [ ] FAL API key working (test generation)
3. [ ] HTTPS enabled and working
4. [ ] All blog URLs with clean format working
5. [ ] All images loading properly
6. [ ] config.php has production values
7. [ ] .htaccess has HTTPS redirect uncommented
8. [ ] File permissions correct (644 files, 755 directories)
9. [ ] Rate limiting working
10. [ ] Error pages working (test 404)
11. [ ] Contact form working (if applicable)
12. [ ] Google Analytics tracking (if configured)

---

**Status:** ✅ All pre-deployment fixes complete. Ready for production upload once config.php is set up and .htaccess HTTPS is enabled.

**Last Updated:** 2024-11-27
