<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

$pageTitle = "Free AI Anime Gallery - Examples & Inspiration | " . SITE_NAME;
$pageDescription = "Browse our gallery of stunning AI-generated anime art. Get inspiration for your prompts and see what's possible with our free anime generator. No sign-up required.";
$pageKeywords = "ai anime gallery, anime art examples, ai generated anime, anime inspiration, free anime gallery, anime prompts";
$canonicalUrl = SITE_URL . "/gallery.php";

$galleryItems = [
    [
        'image' => '/assets/img/gallery/anime-girl-silver-hair-school-uniform.jpg',
        'prompt' => 'Anime girl with long silver hair, wearing school uniform, cherry blossoms falling in background, soft afternoon lighting, gentle smile, detailed eyes',
        'category' => 'Character'
    ],
    [
        'image' => '/assets/img/gallery/anime-girl-pink-hair-cat-ears.jpg',
        'prompt' => 'Anime portrait, girl with short pink hair and cat ears, green eyes, playful expression, urban rooftop background, sunset lighting, modern outfit',
        'category' => 'Character'
    ],
    [
        'image' => '/assets/img/gallery/anime-boy-white-hair-school-uniform-sakura.jpg',
        'prompt' => 'Anime boy with messy white hair, school uniform, confident expression, standing under sakura tree, wind blowing, detailed shading',
        'category' => 'Character'
    ],
    [
        'image' => '/assets/img/gallery/anime-warrior-boy-silver-armor-fantasy.jpg',
        'prompt' => 'Anime warrior boy with silver armor, blue cape flowing, sword at side, determined expression, fantasy battlefield, dramatic sky',
        'category' => 'Fantasy'
    ],
    [
        'image' => '/assets/img/gallery/angel-anime-character-white-wings-divine.jpg',
        'prompt' => 'Angel anime character with large white wings, flowing white dress, golden halo, clouds background, divine lighting, peaceful expression',
        'category' => 'Fantasy'
    ],
    [
        'image' => '/assets/img/gallery/chibi-anime-girl-kawaii-pastel-dress.jpg',
        'prompt' => 'Chibi anime girl, big sparkling eyes, cute expression, pastel pink dress, holding stuffed animal, simple gradient background, kawaii style',
        'category' => 'Chibi'
    ],
    [
        'image' => '/assets/img/gallery/chibi-anime-witch-magic-wand.jpg',
        'prompt' => 'Chibi anime character, witch outfit with pointed hat, holding magic wand, stars and sparkles, colorful background, adorable proportions',
        'category' => 'Chibi'
    ],
    [
        'image' => '/assets/img/gallery/chibi-anime-boy-gaming-controller.jpg',
        'prompt' => 'Chibi anime boy, oversized hoodie, gaming controller, excited expression, colorful geometric background, super deformed style',
        'category' => 'Chibi'
    ],
    [
        'image' => '/assets/img/gallery/manga-style-dramatic-girl-emotional.jpg',
        'prompt' => 'Manga style dramatic scene, close-up of anime girl face, intense expression, speed lines, black and white with screen tones, emotional',
        'category' => 'Manga'
    ],
    [
        'image' => '/assets/img/gallery/manga-style-character-running-action.jpg',
        'prompt' => 'Manga panel style, anime character running with determination, motion blur effects, action lines, monochrome with contrast, dynamic composition',
        'category' => 'Manga'
    ],
    [
        'image' => '/assets/img/gallery/anime-cyberpunk-city-night-neon-lights.jpg',
        'prompt' => 'Anime landscape, futuristic cyberpunk city at night, neon signs, rain reflections, flying cars, purple and cyan color scheme, detailed architecture',
        'category' => 'Landscape'
    ],
    [
        'image' => '/assets/img/gallery/fantasy-anime-floating-islands-magical.jpg',
        'prompt' => 'Fantasy anime background, floating islands in sky, waterfalls, magical crystals, rainbow light effects, dreamy clouds, vibrant colors',
        'category' => 'Landscape'
    ]
];

include __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h2 class="hero-title">AI Anime Gallery - Examples & Inspiration</h2>
            <p class="hero-subtitle">Browse stunning anime art created with our free generator</p>
        </div>
    </div>
</section>

<!-- Gallery Section -->
<section class="section">
    <div class="container">
        <div class="gallery-filter">
            <button class="filter-btn active" data-category="all">All</button>
            <button class="filter-btn" data-category="character">Characters</button>
            <button class="filter-btn" data-category="fantasy">Fantasy</button>
            <button class="filter-btn" data-category="chibi">Chibi</button>
            <button class="filter-btn" data-category="manga">Manga</button>
            <button class="filter-btn" data-category="landscape">Landscapes</button>
        </div>

        <div class="gallery-grid">
            <?php foreach ($galleryItems as $item): ?>
            <div class="gallery-item" data-category="<?php echo strtolower($item['category']); ?>">
                <img
                    src="<?php echo htmlspecialchars($item['image']); ?>"
                    alt="<?php echo htmlspecialchars($item['prompt']); ?>"
                    class="gallery-item-image"
                    loading="lazy"
                    onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22280%22 height=%22280%22%3E%3Crect fill=%22%23f1f5f9%22 width=%22280%22 height=%22280%22/%3E%3Ctext fill=%22%2394a3b8%22 font-family=%22sans-serif%22 font-size=%2214%22 text-anchor=%22middle%22 x=%22140%22 y=%22145%22%3EExample Image%3C/text%3E%3C/svg%3E'"
                >
                <div class="gallery-item-info">
                    <span class="gallery-item-category"><?php echo htmlspecialchars($item['category']); ?></span>
                    <p class="gallery-item-prompt"><?php echo htmlspecialchars($item['prompt']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- CTA Section -->
        <div style="text-align: center; margin-top: 4rem;">
            <h3 style="font-size: 2rem; margin-bottom: 1rem;">Ready to Create Your Own?</h3>
            <p style="color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.125rem;">Generate stunning anime art for free - no sign-up required</p>
            <a href="/" class="btn btn-primary btn-large" style="max-width: 300px; display: inline-block;">Start Generating Free</a>
        </div>
    </div>
</section>

<!-- SEO Content Section -->
<section class="section section-alt">
    <div class="container">
        <div style="max-width: 800px; margin: 0 auto;">
            <h2 class="section-title">Free AI Anime Gallery - Inspiration & Examples</h2>
            <div style="color: var(--text-secondary); line-height: 1.8; font-size: 1.125rem;">
                <p>Welcome to our free AI anime gallery! Here you'll find examples of stunning anime art generated using our free anime generator. Each image in this gallery was created using simple text prompts - no artistic skills required.</p>

                <h3 style="font-size: 1.5rem; margin-top: 2rem; margin-bottom: 1rem; color: var(--text-primary);">What Can You Generate?</h3>
                <ul style="margin-bottom: 2rem;">
                    <li><strong>Anime Characters:</strong> Create custom characters with unique hairstyles, outfits, and expressions</li>
                    <li><strong>Fantasy Scenes:</strong> Generate magical girls, warriors, and fantasy characters with special effects</li>
                    <li><strong>Chibi Style:</strong> Make adorable chibi characters with big eyes and cute proportions</li>
                    <li><strong>Manga Art:</strong> Create dramatic manga-style illustrations and scenes</li>
                    <li><strong>Anime Landscapes:</strong> Generate beautiful anime backgrounds and scenery</li>
                </ul>

                <h3 style="font-size: 1.5rem; margin-top: 2rem; margin-bottom: 1rem; color: var(--text-primary);">How to Use Prompts</h3>
                <p>The key to great anime generation is writing detailed prompts. Each image in this gallery includes the prompt used to create it. Study these examples to improve your own generations:</p>
                <ul style="margin-bottom: 2rem;">
                    <li>Describe the character's appearance (hair, eyes, outfit)</li>
                    <li>Specify the scene or background</li>
                    <li>Include lighting and mood</li>
                    <li>Add style keywords like "anime", "manga", "chibi", etc.</li>
                </ul>

                <h3 style="font-size: 1.5rem; margin-top: 2rem; margin-bottom: 1rem; color: var(--text-primary);">100% Free - No Sign-Up Required</h3>
                <p>Unlike other AI anime generators, we don't require registration, email, or payment. Simply visit our homepage, describe what you want, and generate beautiful anime art instantly. Perfect for:</p>
                <ul>
                    <li>Social media profile pictures</li>
                    <li>Character design inspiration</li>
                    <li>Story and game development</li>
                    <li>Art reference and practice</li>
                    <li>Discord avatars and server icons</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<script>
// Gallery filter functionality
document.addEventListener('DOMContentLoaded', function() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.dataset.category;

            // Update active state
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            // Filter items
            galleryItems.forEach(item => {
                if (category === 'all' || item.dataset.category === category) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
