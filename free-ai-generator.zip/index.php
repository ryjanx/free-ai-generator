<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

session_start();
$csrf_token = generateCSRFToken();
$clientIP = getClientIP();

// Get remaining generations
$ipUsage = new IPUsageModel();
$remainingGenerations = $ipUsage->getRemainingGenerations($clientIP);
$limitReached = $ipUsage->hasReachedLimit($clientIP);

// SEO Meta
$pageTitle = "Free AI Anime Generator - No Sign-Up Required | Create Anime Art Instantly";
$pageDescription = "Generate stunning anime images instantly with our free AI anime generator. No sign-up, no credit card, no login required. Create anime characters, manga art, and fantasy scenes in seconds with advanced AI.";
$pageKeywords = "free ai anime generator, anime generator free, ai anime art generator, anime character generator free, no signup anime generator, free anime ai, create anime free, manga generator";
$canonicalUrl = SITE_URL . "/";

include __DIR__ . '/includes/header.php';
?>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h2 class="hero-title">Free AI Anime Generator - No Sign-Up Required</h2>
                <p class="hero-subtitle">Create stunning anime art instantly • 100% Free • No login needed</p>
            </div>
        </div>
    </section>

    <!-- Generator Section -->
    <section class="generator-section">
        <div class="container">
            <?php if ($limitReached): ?>
                <!-- Limit Reached Message -->
                <div class="limit-reached-card">
                    <div class="limit-icon">🎨</div>
                    <h3>You've Used All Your Free Generations!</h3>
                    <p>Want to generate more anime art? Contact us below.</p>
                    <button id="showContactBtn" class="btn btn-primary" style="margin-top:20px">Contact Us for More</button>
                </div>
            <?php else: ?>
                <!-- Generator Form -->
                <div class="generator-card">
                    <form id="generatorForm">
                        <div class="form-group">
                            <label for="prompt" class="form-label">
                                Describe Your Anime Image
                                <span class="label-hint">Be specific for best results</span>
                            </label>
                            <textarea
                                id="prompt"
                                name="prompt"
                                class="form-textarea"
                                rows="4"
                                placeholder="e.g., Anime girl with long silver hair, wearing school uniform, cherry blossoms background, soft lighting"
                                required
                                maxlength="1000"
                            ></textarea>
                            <div class="char-count">
                                <span id="charCount">0</span> / 1000 characters
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="aspectRatio" class="form-label">Aspect Ratio</label>
                            <div class="ratio-grid">
                                <?php foreach (ALLOWED_ASPECT_RATIOS as $ratio => $config): ?>
                                    <label class="ratio-option">
                                        <input type="radio" name="aspectRatio" value="<?php echo $ratio; ?>" <?php echo $ratio === '1:1' ? 'checked' : ''; ?>>
                                        <div class="ratio-card">
                                            <div class="ratio-preview" data-ratio="<?php echo $ratio; ?>"></div>
                                            <span class="ratio-label"><?php echo htmlspecialchars($config['label']); ?></span>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                        <button type="submit" class="btn btn-primary btn-large" id="generateBtn">
                            <span class="btn-text">Generate Image</span>
                            <span class="btn-loader" style="display: none;">
                                <span class="spinner"></span> Generating...
                            </span>
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Contact Modal -->
    <div id="contactModal" class="modal">
        <div class="modal-content">
            <span class="modal-close">&times;</span>
            <h3 class="modal-title">Contact Us</h3>
            <p class="modal-subtitle">Want more free generations or have a business inquiry?</p>

            <form id="contactForm">
                <div class="form-group">
                    <label for="contactName" class="form-label">Name</label>
                    <input type="text" id="contactName" name="name" class="form-input" required>
                </div>

                <div class="form-group">
                    <label for="contactEmail" class="form-label">Email</label>
                    <input type="email" id="contactEmail" name="email" class="form-input" required>
                </div>

                <div class="form-group">
                    <label for="contactReason" class="form-label">Reason</label>
                    <select id="contactReason" name="reason" class="form-select">
                        <option value="more_generations">I want more free generations</option>
                        <option value="business">Business inquiry</option>
                        <option value="support">Technical support</option>
                        <option value="other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="contactMessage" class="form-label">Message</label>
                    <textarea id="contactMessage" name="message" class="form-textarea" rows="4" required></textarea>
                </div>

                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                <button type="submit" class="btn btn-primary btn-large" id="contactSubmitBtn">
                    Send Message
                </button>
            </form>

            <div id="contactSuccess" class="alert alert-success" style="display: none;">
                Thank you! We'll get back to you soon.
            </div>
        </div>
    </div>

    <!-- How It Works Section -->
    <section id="how-it-works" class="section">
        <div class="container">
            <h2 class="section-title">How to Use the Free AI Anime Generator</h2>
            <div class="steps-grid">
                <div class="step-card">
                    <div class="step-number">1</div>
                    <h3>Describe Your Anime</h3>
                    <p>Type what anime image you want to create. Describe the character, scene, mood, and style - the AI does the rest.</p>
                </div>
                <div class="step-card">
                    <div class="step-number">2</div>
                    <h3>Pick Your Size</h3>
                    <p>Choose from square, landscape, or portrait formats. Perfect for social media, wallpapers, or character designs.</p>
                </div>
                <div class="step-card">
                    <div class="step-number">3</div>
                    <h3>Generate Instantly</h3>
                    <p>Click generate and watch your anime art appear in seconds. Save it and use it anywhere - 100% free!</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Showcase Section -->
    <section class="section" style="background: var(--background-alt);">
        <div class="container">
            <h2 class="section-title">See What You Can Create</h2>
            <p style="text-align: center; color: var(--text-secondary); max-width: 600px; margin: 0 auto 3rem;">
                Real examples generated by our free AI anime generator - all created in under 10 seconds
            </p>

            <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; margin-bottom: 2rem;">
                <div style="width: 200px; border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-lg);">
                    <img src="/assets/img/gallery/anime-girl-silver-hair-school-uniform.jpg" alt="Anime girl with silver hair" style="width: 100%; height: 200px; object-fit: cover; display: block;">
                </div>
                <div style="width: 200px; border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-lg);">
                    <img src="/assets/img/gallery/anime-girl-pink-hair-cat-ears.jpg" alt="Anime girl with pink hair" style="width: 100%; height: 200px; object-fit: cover; display: block;">
                </div>
                <div style="width: 200px; border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-lg);">
                    <img src="/assets/img/gallery/chibi-anime-girl-kawaii-pastel-dress.jpg" alt="Cute chibi character" style="width: 100%; height: 200px; object-fit: cover; display: block;">
                </div>
                <div style="width: 200px; border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-lg);">
                    <img src="/assets/img/gallery/anime-warrior-boy-silver-armor-fantasy.jpg" alt="Fantasy warrior character" style="width: 100%; height: 200px; object-fit: cover; display: block;">
                </div>
                <div style="width: 200px; border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-lg);">
                    <img src="/assets/img/gallery/chibi-anime-witch-magic-wand.jpg" alt="Chibi witch character" style="width: 100%; height: 200px; object-fit: cover; display: block;">
                </div>
            </div>

            <div style="text-align: center;">
                <a href="/gallery" class="btn btn-primary" style="display: inline-block;">View Full Gallery</a>
            </div>
        </div>
    </section>

    <!-- Examples Section -->
    <section id="examples" class="section section-alt">
        <div class="container">
            <h2 class="section-title">What You Can Generate (100% Free)</h2>
            <div class="examples-grid">
                <div class="example-card">
                    <h3>👧 Anime Characters</h3>
                    <p>Generate custom anime characters with unique hairstyles, outfits, and expressions. Perfect for OCs, stories, or games.</p>
                </div>
                <div class="example-card">
                    <h3>🌸 Manga-Style Art</h3>
                    <p>Create manga illustrations with dramatic scenes, emotions, and cinematic compositions in seconds.</p>
                </div>
                <div class="example-card">
                    <h3>🏯 Anime Backgrounds</h3>
                    <p>Generate stunning anime scenery - from cherry blossom gardens to futuristic cities and fantasy worlds.</p>
                </div>
                <div class="example-card">
                    <h3>⚔️ Fantasy Characters</h3>
                    <p>Create anime warriors, magical girls, and heroes with detailed armor, weapons, and special effects.</p>
                </div>
                <div class="example-card">
                    <h3>💫 Chibi & Cute Styles</h3>
                    <p>Generate adorable chibi characters with big eyes, cute proportions, and playful expressions.</p>
                </div>
                <div class="example-card">
                    <h3>📱 Profile Pictures</h3>
                    <p>Create unique anime avatars and PFPs for Discord, Twitter, Instagram, YouTube, and more.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section id="faq" class="section">
        <div class="container">
            <h2 class="section-title">Free AI Anime Generator - FAQ</h2>
            <div class="faq-grid">
                <div class="faq-item">
                    <h3>Is this anime generator really free?</h3>
                    <p>Yes! 100% free with no hidden costs. You get <?php echo MAX_GENERATIONS_PER_IP; ?> free anime generations. No credit card, no sign-up, no payment required.</p>
                </div>
                <div class="faq-item">
                    <h3>Do I need to create an account?</h3>
                    <p>No sign-up required! Just visit the site, type your prompt, and generate anime art instantly. No registration, no login, no email needed.</p>
                </div>
                <div class="faq-item">
                    <h3>How does this AI anime generator work?</h3>
                    <p>Our advanced AI transforms your text descriptions into anime-style images in seconds using the latest machine learning technology.</p>
                </div>
                <div class="faq-item">
                    <h3>How fast is the generation?</h3>
                    <p>Super fast! Most anime images are generated in just 3-10 seconds. No waiting, no queues.</p>
                </div>
                <div class="faq-item">
                    <h3>Can I use the generated anime commercially?</h3>
                    <p>Yes! All generated anime images are yours to use for personal or commercial projects - completely free.</p>
                </div>
                <div class="faq-item">
                    <h3>Is my data stored or tracked?</h3>
                    <p>No tracking, no cookies, no data collection. Your privacy is 100% protected. Images are temporary and not stored.</p>
                </div>
            </div>
        </div>
    </section>

<?php include __DIR__ . '/includes/footer.php'; ?>
