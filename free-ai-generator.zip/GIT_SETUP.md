# Git Setup Guide - Free AI Generator

## 🚨 Before Starting

**CRITICAL:** Your current `config.php` contains sensitive data:
- Database credentials
- FAL API keys
- Admin email

These should **NEVER** be committed to Git!

---

## Quick Setup (Copy-Paste These Commands)

```bash
# Navigate to your project
cd /home/achakmakov/Desktop/cld

# Initialize Git repository
git init

# Check that .gitignore exists
cat .gitignore

# Add all files (config.php is ignored automatically)
git add .

# Check what will be committed (config.php should NOT appear)
git status

# Make first commit
git commit -m "Initial commit: Free AI Anime Generator

- Blog system with 5 SEO-optimized posts
- Gallery page for showcasing examples
- Reusable header/footer components
- Google Analytics integration
- Clean URLs with .htaccess
- Complete SEO optimization
- Mobile-responsive design"

# View commit
git log --oneline
```

---

## Create GitHub Repository (Optional but Recommended)

### Option 1: Using GitHub CLI (if installed)

```bash
# Login to GitHub
gh auth login

# Create new repository
gh repo create free-ai-generator --public --source=. --remote=origin

# Push code
git push -u origin main
```

### Option 2: Using Web Interface

1. Go to https://github.com/new
2. Repository name: `free-ai-generator`
3. Description: "Free AI Anime Generator - No sign-up required"
4. Choose Public or Private
5. **Don't** initialize with README (you already have files)
6. Click "Create repository"

Then run:
```bash
# Add remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/free-ai-generator.git

# Push code
git branch -M main
git push -u origin main
```

---

## Verify Secret Files Are Ignored

**Run this to confirm sensitive files aren't tracked:**

```bash
# These commands should return nothing or "not tracked"
git ls-files | grep config.php
git ls-files | grep ".env"

# If config.php appears, you did something wrong! Remove it:
git rm --cached config.php
git commit -m "Remove sensitive config file"
```

---

## Files That Are Ignored (Won't Be Committed)

According to `.gitignore`:
- ❌ `config.php` - **Contains secrets!**
- ❌ `*.sql` - Database dumps
- ❌ `*.log` - Log files
- ❌ `/assets/gallery/*.jpg` - Gallery images (optional, can be large)
- ❌ `.env` - Environment variables
- ❌ IDE files (.vscode, .idea)

---

## Files That WILL Be Committed (Safe)

- ✅ `config.example.php` - Template without secrets
- ✅ All `.php` files (except config.php)
- ✅ `/blog/` directory with posts
- ✅ `/includes/` header and footer
- ✅ `gallery.php`
- ✅ `.htaccess`
- ✅ `sitemap.xml`
- ✅ `robots.txt`
- ✅ CSS, JS files
- ✅ Documentation (`.md` files)

---

## Setting Up Production Server

When deploying to production:

```bash
# On your local machine - push to Git
git push origin main

# On production server - pull from Git
cd /var/www/html  # or your web directory
git clone https://github.com/YOUR_USERNAME/free-ai-generator.git .

# Create config.php from example
cp config.example.php config.php

# Edit config.php with production values
nano config.php

# Set permissions
chmod 644 config.php
chmod 755 blog/
chmod 755 assets/gallery/

# Done!
```

---

## Daily Workflow

### Making Changes

```bash
# See what changed
git status

# See detailed changes
git diff

# Add specific files
git add blog/posts/new-post.php
git add gallery.php

# Or add all changes
git add .

# Commit with message
git commit -m "Add new blog post about anime prompts"

# Push to remote
git push
```

### Updating Production

```bash
# SSH into production server
ssh user@your-server.com

# Navigate to project
cd /var/www/html

# Pull latest changes
git pull origin main

# If config.php updated, manually update it
# (never commit actual config.php)
```

---

## Branch Strategy (Optional)

For safer development:

```bash
# Create development branch
git checkout -b development

# Make changes and commit
git add .
git commit -m "Add new feature"

# Push development branch
git push -u origin development

# When ready, merge to main
git checkout main
git merge development
git push origin main
```

---

## Useful Git Commands

```bash
# View commit history
git log --oneline --graph

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Discard all local changes (DANGEROUS!)
git reset --hard HEAD

# See what changed in a file
git diff blog/index.php

# View file as it was in last commit
git show HEAD:blog/index.php

# Create tag for release
git tag -a v1.0.0 -m "Version 1.0.0 - Initial release"
git push --tags
```

---

## .gitignore Explained

```gitignore
# Never commit sensitive data
config.php          # Contains API keys, DB passwords
*.sql              # Database dumps with user data

# Ignore large files
/assets/gallery/*.jpg   # Images can be huge
node_modules/          # Dependencies (if added later)

# Ignore IDE files
.vscode/           # VS Code settings
.idea/            # PHPStorm settings
.DS_Store         # Mac OS files
```

---

## Backup Strategy

Git is NOT a backup! Use both:

**1. Git (for code)**
```bash
git push origin main  # Push to GitHub
```

**2. Separate backup (for database + images)**
```bash
# Backup database
mysqldump -u user -p database > backup.sql

# Backup gallery images
tar -czf gallery-backup.tar.gz assets/gallery/

# Store somewhere safe (not in Git!)
```

---

## Common Mistakes to Avoid

### ❌ DON'T:
```bash
# Never commit config.php
git add config.php  # BAD!

# Never commit database dumps
git add database.sql  # BAD!

# Never commit large files
git add huge-video.mp4  # BAD!
```

### ✅ DO:
```bash
# Use config.example.php
git add config.example.php  # GOOD!

# Update .gitignore if needed
echo "new-sensitive-file.txt" >> .gitignore
git add .gitignore
git commit -m "Update gitignore"
```

---

## If You Accidentally Commit Secrets

**Emergency fix:**

```bash
# Remove from Git history (DANGER!)
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch config.php' \
  --prune-empty --tag-name-filter cat -- --all

# Force push to remote (if already pushed)
git push origin --force --all

# IMPORTANT: Immediately change all passwords/API keys
# that were exposed! They're now in Git history forever
# on any forks/clones
```

Better: **Create new repository** if you leak secrets early on.

---

## Setting Up .env (Alternative to config.php)

Some prefer `.env` files:

```bash
# Create .env
cp .env.example .env
nano .env

# In .env:
DB_HOST=localhost
DB_NAME=database_name
FAL_API_KEY=your-key

# Load in PHP (requires vlucas/phpdotenv)
# composer require vlucas/phpdotenv
```

---

## Deployment Checklist

Before going live:

- [ ] config.php NOT in Git ✓
- [ ] API keys changed from development
- [ ] Database credentials correct
- [ ] Google Analytics ID added
- [ ] SITE_URL set to production domain
- [ ] .htaccess uploaded
- [ ] File permissions correct (644 for files, 755 for directories)
- [ ] Error reporting off in production
- [ ] SSL certificate installed
- [ ] Backups configured

---

## Git Workflow Summary

```bash
# Daily workflow
git pull          # Get latest changes
# ... make changes ...
git add .         # Stage changes
git commit -m ""  # Commit with message
git push          # Upload to remote

# That's it!
```

---

## Need Help?

- Git documentation: https://git-scm.com/doc
- GitHub guides: https://guides.github.com/
- Git cheat sheet: https://education.github.com/git-cheat-sheet-education.pdf

---

## Quick Reference Card

```bash
# Setup (once)
git init
git add .
git commit -m "Initial commit"
git remote add origin URL
git push -u origin main

# Daily use
git status        # What changed?
git add .         # Stage all
git commit -m ""  # Save changes
git push          # Upload

# See history
git log --oneline

# Undo (careful!)
git reset --soft HEAD~1    # Undo commit, keep changes
git checkout -- file.php   # Discard file changes
```

**Remember:** Never commit config.php or any file with passwords/API keys!
