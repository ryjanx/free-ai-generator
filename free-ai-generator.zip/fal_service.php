<?php
require_once __DIR__ . '/config.php';

class FalService {
    private $apiKey;
    private $apiUrl;

    public function __construct() {
        $this->apiKey = FAL_API_KEY;
        $this->apiUrl = FAL_API_URL;
    }

    /**
     * Generate image using FAL API with queue
     */
    public function generateImage($prompt, $aspectRatio = '1:1') {
        // Get aspect ratio dimensions
        $ratioConfig = ALLOWED_ASPECT_RATIOS[$aspectRatio] ?? ALLOWED_ASPECT_RATIOS['1:1'];

        // Prepare webhook URL as query parameter (FAL API uses query params, not headers)
        $webhookUrl = SITE_URL . '/api/webhook.php';
        $queueUrl = $this->apiUrl . '?fal_webhook=' . urlencode($webhookUrl);

        // Prepare request payload
        // Note: FAL API accepts custom width/height in image_size object
        $payload = [
            'prompt' => $prompt,
            'image_size' => [
                'width' => $ratioConfig['width'],
                'height' => $ratioConfig['height']
            ],
            'num_inference_steps' => 5,
            'num_images' => 1,
            'enable_safety_checker' => false,
            'output_format' => 'jpeg'
        ];

        try {
            // Submit to queue with webhook in URL
            $response = $this->makeRequest('POST', $queueUrl, $payload);

            if (isset($response['request_id'])) {
                // Build status URL for polling fallback
                $statusUrl = str_replace('/schnell', '/schnell/requests/' . $response['request_id'] . '/status', $this->apiUrl);

                return [
                    'success' => true,
                    'request_id' => $response['request_id'],
                    'status_url' => $statusUrl,
                    'response_url' => $response['response_url'] ?? null
                ];
            }

            return [
                'success' => false,
                'error' => 'Invalid API response'
            ];

        } catch (Exception $e) {
            error_log("FAL API Error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get status of a queued generation
     */
    public function getStatus($statusUrl) {
        try {
            $response = $this->makeRequest('GET', $statusUrl);
            return $response;
        } catch (Exception $e) {
            error_log("FAL Status Check Error: " . $e->getMessage());
            return [
                'status' => 'error',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get result from completed generation
     */
    public function getResult($responseUrl) {
        try {
            $response = $this->makeRequest('GET', $responseUrl);
            return $response;
        } catch (Exception $e) {
            error_log("FAL Result Error: " . $e->getMessage());
            return [
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Make HTTP request to FAL API
     */
    private function makeRequest($method, $url, $data = null, $extraHeaders = []) {
        $ch = curl_init();

        $headers = [
            'Authorization: Key ' . $this->apiKey,
            'Content-Type: application/json',
        ];

        foreach ($extraHeaders as $key => $value) {
            $headers[] = "$key: $value";
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("cURL Error: $error");
        }

        if ($httpCode >= 400) {
            $errorData = json_decode($response, true);
            $errorMsg = $errorData['detail'] ?? $errorData['error'] ?? 'API request failed';
            throw new Exception("API Error ($httpCode): $errorMsg");
        }

        $decoded = json_decode($response, true);
        if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response from API");
        }

        return $decoded;
    }

}
