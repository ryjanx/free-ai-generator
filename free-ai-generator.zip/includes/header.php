<?php
// Ensure config is loaded
if (!defined('SITE_URL')) {
    require_once __DIR__ . '/../config.php';
}

// Default meta values if not set
if (!isset($pageTitle)) $pageTitle = "Free AI Anime Generator - No Sign-Up Required | Create Anime Art Instantly";
if (!isset($pageDescription)) $pageDescription = "Generate stunning anime images instantly with our free AI anime generator. No sign-up, no credit card, no login required. Create anime characters, manga art, and fantasy scenes in seconds with advanced AI.";
if (!isset($pageKeywords)) $pageKeywords = "free ai anime generator, anime generator free, ai anime art generator, anime character generator free, no signup anime generator, free anime ai, create anime free, manga generator";
if (!isset($ogImage)) $ogImage = SITE_URL . "/assets/og-image.jpg";
if (!isset($canonicalUrl)) $canonicalUrl = SITE_URL . $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($pageKeywords); ?>">

    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo htmlspecialchars($canonicalUrl); ?>">
    <meta property="og:image" content="<?php echo htmlspecialchars($ogImage); ?>">
    <meta property="og:site_name" content="<?php echo SITE_NAME; ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="twitter:image" content="<?php echo htmlspecialchars($ogImage); ?>">

    <!-- Canonical -->
    <link rel="canonical" href="<?php echo htmlspecialchars($canonicalUrl); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/assets/favicon.ico">

    <!-- Styles -->
    <link rel="stylesheet" href="/assets/css/style.css?v=3">

    <!-- Preconnect for performance -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- RSS Feed -->
    <link rel="alternate" type="application/rss+xml" title="Free AI Anime Generator Blog" href="<?php echo SITE_URL; ?>/blog/rss.xml">

    <!-- Google Analytics - Replace with your tracking ID -->
    <?php if (defined('GOOGLE_ANALYTICS_ID') && GOOGLE_ANALYTICS_ID): ?>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo GOOGLE_ANALYTICS_ID; ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '<?php echo GOOGLE_ANALYTICS_ID; ?>');
    </script>
    <?php endif; ?>

    <!-- Schema.org structured data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "<?php echo SITE_NAME; ?>",
        "description": "<?php echo htmlspecialchars($pageDescription); ?>",
        "url": "<?php echo SITE_URL; ?>",
        "applicationCategory": "MultimediaApplication",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
        },
        "operatingSystem": "Any",
        "permissions": "No registration required"
    }
    </script>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="/" class="logo-link">
                    <h1 class="logo">⚡ Free AI Anime Generator</h1>
                </a>
                <nav class="nav">
                    <a href="/" class="nav-link">Generator</a>
                    <a href="/gallery" class="nav-link">Gallery</a>
                    <a href="/blog/" class="nav-link">Blog</a>
                    <a href="/#how-it-works" class="nav-link">How It Works</a>
                    <a href="/#faq" class="nav-link">FAQ</a>
                </nav>
            </div>
        </div>
    </header>
