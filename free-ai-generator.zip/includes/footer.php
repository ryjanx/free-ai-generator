    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-links">
                    <a href="/" class="footer-link">Home</a>
                    <a href="/gallery" class="footer-link">Gallery</a>
                    <a href="/blog/" class="footer-link">Blog</a>
                    <a href="/#how-it-works" class="footer-link">How It Works</a>
                    <a href="/#faq" class="footer-link">FAQ</a>
                </div>
                <p class="footer-copy">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. 100% Free • No Sign-Up Required</p>
                <p class="footer-note">Your privacy matters. No data collection • No cookies • No tracking</p>
                <p class="footer-note" style="margin-top: 1rem; opacity: 0.6;">
                    Keywords: free ai anime generator, anime art generator, manga generator, ai anime characters, no signup anime generator
                </p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/js/app.js?v=2"></script>
</body>
</html>
