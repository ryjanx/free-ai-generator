<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'btctszin_freegen15316');
define('DB_USER', 'btctszin_freegenuser51903');
define('DB_PASS', 'aPQ6O6*7xM}~');
define('DB_CHARSET', 'utf8mb4');

// FAL API Configuration
define('FAL_API_KEY', '87cf2868-c4b7-4e77-844a-9e239c498006:fe874f3b8d532fa90bd139a0b106aaa1');
define('FAL_API_URL', 'https://queue.fal.run/fal-ai/flux/schnell');

// Application settings
define('SITE_URL', 'https://free-ai-generator.com');
define('SITE_NAME', 'Free AI Anime Generator');
define('MAX_GENERATIONS_PER_IP', 3);
define('GENERATION_TIMEOUT', 120); // seconds

// Google Analytics - Add your tracking ID here
// Get your ID from: https://analytics.google.com/
// Example: 'G-XXXXXXXXXX' or 'UA-XXXXXXXXX-X'
define('GOOGLE_ANALYTICS_ID', 'G-CCS3YHMTXH'); // Leave empty to disable

// Image settings
define('MAX_IMAGE_SIZE', 1048576); // 1MP in pixels
define('ALLOWED_ASPECT_RATIOS', [
    '1:1' => ['width' => 640, 'height' => 640, 'label' => 'Square (1:1)'],
    '16:9' => ['width' => 640, 'height' => 360, 'label' => 'Landscape (16:9)'],
    '9:16' => ['width' => 360, 'height' => 640, 'label' => 'Portrait (9:16)'],
    '4:3' => ['width' => 640, 'height' => 480, 'label' => 'Classic (4:3)'],
    '3:4' => ['width' => 480, 'height' => 640, 'label' => 'Portrait (3:4)'],
]);

// Contact email
define('ADMIN_EMAIL', 'alex.chakmakov@protonmail.com');

// Security
define('SESSION_NAME', 'fal_gen_session');

// Timezone
date_default_timezone_set('UTC');

// CSRF Token generation
function generateCSRFToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Verify CSRF Token
function verifyCSRFToken($token) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Get client IP address
function getClientIP() {
    $ip = '';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        // CloudFlare
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    // Validate IP
    return filter_var(trim($ip), FILTER_VALIDATE_IP) ? trim($ip) : '0.0.0.0';
}

// Generate session token for generation tracking
function generateSessionToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['generation_tokens'])) {
        $_SESSION['generation_tokens'] = [];
    }
    $token = bin2hex(random_bytes(32));
    $_SESSION['generation_tokens'][$token] = true;
    return $token;
}

// Verify session token for generation access
function verifyGenerationToken($token) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return isset($_SESSION['generation_tokens'][$token]);
}

// Sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// JSON response helper
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
