<?php
// api/webhook.php - Handle FAL API webhook callbacks

header('Content-Type: application/json');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../fal_service.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('error' => 'Method not allowed'));
    exit;
}

$rawPayload = file_get_contents('php://input');
$payload = json_decode($rawPayload, true);

if (!$payload) {
    error_log("Webhook: Invalid JSON payload: " . $rawPayload);
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid JSON'));
    exit;
}

try {
    error_log("Webhook received: " . json_encode($payload));

    $requestId = null;
    if (isset($payload['request_id'])) {
        $requestId = $payload['request_id'];
    }

    if (!$requestId) {
        error_log("Webhook: No request_id in payload");
        http_response_code(400);
        echo json_encode(array('error' => 'Missing request_id'));
        exit;
    }

    $generationModel = new GenerationModel();
    $generation = $generationModel->getByRequestId($requestId);

    if (!$generation) {
        error_log("Webhook: Generation not found for request_id: " . $requestId);
        http_response_code(404);
        echo json_encode(array('error' => 'Generation not found'));
        exit;
    }

    $status = null;
    if (isset($payload['status'])) {
        $status = $payload['status'];
    }

    // Extract images from new FAL format (payload.images) or legacy (images)
    $images = null;

    if (isset($payload['payload']) && is_array($payload['payload'])) {
        if (isset($payload['payload']['images']) && is_array($payload['payload']['images']) && count($payload['payload']['images']) > 0) {
            $images = $payload['payload']['images'];
        }
    }

    if ($images === null) {
        if (isset($payload['images']) && is_array($payload['images']) && count($payload['images']) > 0) {
            $images = $payload['images'];
        }
    }

    $topError = null;
    if (isset($payload['error'])) {
        $topError = $payload['error'];
    }

    $nestedError = null;
    if (isset($payload['payload']) && isset($payload['payload']['error'])) {
        $nestedError = $payload['payload']['error'];
    }

    if ($images !== null) {
        $imageUrl = null;

        if (isset($images[0]['url'])) {
            $imageUrl = $images[0]['url'];
        }

        if ($imageUrl) {
            $generationModel->updateStatus($generation['id'], 'completed', $imageUrl);

            error_log("Webhook: Generation {$generation['id']} completed successfully with image: " . $imageUrl);
        } else {
            $generationModel->updateStatus($generation['id'], 'failed', null, 'No image URL in webhook response');

            error_log("Webhook: No image URL found in payload for generation {$generation['id']}");
        }
    } elseif ($status === 'IN_QUEUE' || $status === 'IN_PROGRESS') {
        error_log("Webhook: Generation {$generation['id']} status: " . $status);
    } elseif ($topError || $nestedError) {
        if ($nestedError) {
            $error = $nestedError;
        } else {
            $error = $topError;
        }

        if (is_string($error)) {
            $errorMessage = $error;
        } else {
            if (isset($error['message'])) {
                $errorMessage = $error['message'];
            } else {
                $errorMessage = 'Generation failed';
            }
        }

        $generationModel->updateStatus($generation['id'], 'failed', null, $errorMessage);

        error_log("Webhook: Generation {$generation['id']} failed: " . $errorMessage);
    } else {
        error_log("Webhook: Unexpected payload format for generation {$generation['id']}: " . json_encode($payload));
    }

    http_response_code(200);
    echo json_encode(array('status' => 'received'));

} catch (Exception $e) {
    error_log("Webhook error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(array('error' => 'Internal server error'));
}
