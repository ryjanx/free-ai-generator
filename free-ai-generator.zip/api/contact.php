<?php
// api/contact.php - Handle contact form submissions

header('Content-Type: application/json');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

session_start();

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    jsonResponse(['error' => 'Invalid JSON'], 400);
}

// Verify CSRF token
if (!isset($input['csrf_token']) || !verifyCSRFToken($input['csrf_token'])) {
    jsonResponse(['error' => 'Invalid CSRF token'], 403);
}

// Validate required fields
$errors = [];

$name = trim($input['name'] ?? '');
if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Name must be at least 2 characters';
}

$email = trim($input['email'] ?? '');
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Valid email is required';
}

$message = trim($input['message'] ?? '');
if (empty($message) || strlen($message) < 10) {
    $errors[] = 'Message must be at least 10 characters';
}

$reason = $input['reason'] ?? 'more_generations';
$allowedReasons = ['more_generations', 'business', 'support', 'other'];
if (!in_array($reason, $allowedReasons)) {
    $reason = 'other';
}

if (!empty($errors)) {
    jsonResponse(['error' => implode(', ', $errors)], 400);
}

// Get client IP
$clientIP = getClientIP();

try {
    // Rate limit: max 3 submissions per 24 hours
    $contactModel = new ContactModel();
    $recentCount = $contactModel->getRecentByIP($clientIP, 24);

    if ($recentCount >= 3) {
        jsonResponse([
            'error' => 'You have submitted too many requests. Please wait 24 hours before trying again.'
        ], 429);
    }

    // Save to database
    $contactId = $contactModel->create($clientIP, $email, $name, $message, $reason);

    // Send email notification
    $subject = "New Contact Request - " . ucfirst(str_replace('_', ' ', $reason));
    $emailBody = "New contact request from Free AI Image Generator\n\n";
    $emailBody .= "Name: $name\n";
    $emailBody .= "Email: $email\n";
    $emailBody .= "Reason: $reason\n";
    $emailBody .= "IP: $clientIP\n";
    $emailBody .= "Message:\n$message\n\n";
    $emailBody .= "---\n";
    $emailBody .= "Request ID: $contactId\n";
    $emailBody .= "Time: " . date('Y-m-d H:i:s') . " UTC\n";

    $headers = "From: noreply@free-ai-generator.com\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    @mail(ADMIN_EMAIL, $subject, $emailBody, $headers);

    jsonResponse([
        'success' => true,
        'message' => 'Thank you for contacting us! We will get back to you soon.'
    ], 200);

} catch (Exception $e) {
    error_log("Contact form error: " . $e->getMessage());
    jsonResponse([
        'error' => 'An error occurred while sending your message. Please try again later.'
    ], 500);
}
