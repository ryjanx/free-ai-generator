<?php
// api/generate.php - Handle image generation requests

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../fal_service.php';

// Start session first (before any output)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    jsonResponse(['error' => 'Invalid JSON'], 400);
}

// Verify CSRF token
if (!isset($input['csrf_token'])) {
    jsonResponse(['error' => 'CSRF token missing'], 403);
}

if (!verifyCSRFToken($input['csrf_token'])) {
    jsonResponse(['error' => 'Invalid CSRF token'], 403);
}

// Validate prompt
if (empty($input['prompt'])) {
    jsonResponse(['error' => 'Prompt is required'], 400);
}

$prompt = trim($input['prompt']);
if (strlen($prompt) < 3) {
    jsonResponse(['error' => 'Prompt must be at least 3 characters'], 400);
}

if (strlen($prompt) > 1000) {
    jsonResponse(['error' => 'Prompt must be less than 1000 characters'], 400);
}

// Validate aspect ratio
$aspectRatio = $input['aspect_ratio'] ?? '1:1';
if (!isset(ALLOWED_ASPECT_RATIOS[$aspectRatio])) {
    jsonResponse(['error' => 'Invalid aspect ratio'], 400);
}

// Get client IP
$clientIP = getClientIP();

try {
    // Check rate limit
    $ipUsage = new IPUsageModel();
    
    if ($ipUsage->hasReachedLimit($clientIP)) {
        jsonResponse([
            'error' => 'Generation limit reached',
            'limit_reached' => true,
            'message' => 'You have used all your free generations. Please contact us for more.'
        ], 429);
    }

    $remaining = $ipUsage->getRemainingGenerations($clientIP);

    // Initialize FAL service
    $falService = new FalService();
    
    // Generate image
    $result = $falService->generateImage($prompt, $aspectRatio);

    if (!$result['success']) {
        jsonResponse([
            'error' => 'Failed to generate image: ' . ($result['error'] ?? 'Unknown error')
        ], 500);
    }

    // Generate session token for secure access
    $sessionToken = generateSessionToken();

    // Save to database
    $generationModel = new GenerationModel();
    $generationId = $generationModel->create($clientIP, $prompt, $aspectRatio, $result['request_id'], $sessionToken);

    // Increment usage
    $ipUsage->incrementUsage($clientIP);

    // Return success response
    jsonResponse([
        'success' => true,
        'generation_id' => $generationId,
        'session_token' => $sessionToken,
        'request_id' => $result['request_id'],
        'status_url' => $result['status_url'],
        'remaining_generations' => $remaining - 1,
        'message' => 'Image generation started. Please wait...'
    ], 200);

} catch (Exception $e) {
    error_log("Generation error: " . $e->getMessage());
    jsonResponse([
        'error' => 'An error occurred while processing your request'
    ], 500);
}
