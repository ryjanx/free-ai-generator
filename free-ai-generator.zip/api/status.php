<?php
// api/status.php - Check generation status

header('Content-Type: application/json');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../fal_service.php';

// Only accept GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(array('error' => 'Method not allowed'), 405);
}

$generationId = isset($_GET['id']) ? $_GET['id'] : null;
$sessionToken = isset($_GET['token']) ? $_GET['token'] : null;

if (!$generationId || !is_numeric($generationId)) {
    jsonResponse(array('error' => 'Invalid generation ID'), 400);
}

if (!$sessionToken) {
    jsonResponse(array('error' => 'Missing session token'), 400);
}

session_start();

try {
    if (!verifyGenerationToken($sessionToken)) {
        jsonResponse(array('error' => 'Unauthorized access'), 403);
    }

    $generationModel = new GenerationModel();
    $generation = $generationModel->getByIdAndToken($generationId, $sessionToken);

    if (!$generation) {
        jsonResponse(array('error' => 'Generation not found or access denied'), 404);
    }

    $clientIP = getClientIP();
    if ($generation['ip_address'] !== $clientIP) {
        jsonResponse(array('error' => 'Unauthorized access'), 403);
    }

    // Webhook fallback – only if still pending and we have a FAL request id
    if ($generation['status'] === 'pending' && !empty($generation['fal_request_id'])) {
        $statusUrl = str_replace('/schnell', '/schnell/requests/' . $generation['fal_request_id'] . '/status', FAL_API_URL);

        $falService = new FalService();
        $falStatus = $falService->getStatus($statusUrl);

        // Normalize possible formats from FAL
        $completedAt = null;
        $images = null;
        $error = null;

        if (is_array($falStatus)) {
            if (isset($falStatus['payload']) && is_array($falStatus['payload'])) {
                if (isset($falStatus['payload']['completed_at'])) {
                    $completedAt = $falStatus['payload']['completed_at'];
                }

                if (isset($falStatus['payload']['images']) && is_array($falStatus['payload']['images'])) {
                    $images = $falStatus['payload']['images'];
                }

                if (isset($falStatus['payload']['error'])) {
                    $error = $falStatus['payload']['error'];
                }
            }

            if (isset($falStatus['completed_at']) && !$completedAt) {
                $completedAt = $falStatus['completed_at'];
            }

            if (isset($falStatus['images']) && !$images && is_array($falStatus['images'])) {
                $images = $falStatus['images'];
            }

            if (isset($falStatus['error']) && !$error) {
                $error = $falStatus['error'];
            }
        }

        if ($completedAt && $images && isset($images[0]['url'])) {
            $imageUrl = $images[0]['url'];

            $generationModel->updateStatus($generation['id'], 'completed', $imageUrl);

            $generation['status'] = 'completed';
            $generation['image_url'] = $imageUrl;
            $generation['completed_at'] = date('Y-m-d H:i:s');

            error_log("Status check: Updated generation {$generation['id']} from FAL API (webhook fallback)");
        } elseif ($error) {
            if (is_string($error)) {
                $errorMessage = $error;
            } else {
                if (isset($error['message'])) {
                    $errorMessage = $error['message'];
                } else {
                    $errorMessage = 'Generation failed';
                }
            }

            // Do not hard-fail on our own integration errors like HTTP 405
            if (strpos($errorMessage, '405') !== false || stripos($errorMessage, 'Method not allowed') !== false) {
                error_log("Status check: FAL status endpoint returned 405/Method Not Allowed for generation {$generation['id']}, keeping status '{$generation['status']}'");
            } else {
                $generationModel->updateStatus($generation['id'], 'failed', null, $errorMessage);

                $generation['status'] = 'failed';
                $generation['error_message'] = $errorMessage;

                error_log("Status check: Generation {$generation['id']} failed per FAL API: " . $errorMessage);
            }
        }
    }

    jsonResponse(
        array(
            'success'       => true,
            'status'        => $generation['status'],
            'image_url'     => $generation['image_url'],
            'error_message' => $generation['error_message'],
            'created_at'    => $generation['created_at'],
            'completed_at'  => $generation['completed_at']
        ),
        200
    );

} catch (Exception $e) {
    error_log("Status check error: " . $e->getMessage());
    jsonResponse(array('error' => 'An error occurred'), 500);
}
