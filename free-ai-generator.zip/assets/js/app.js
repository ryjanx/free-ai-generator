// assets/js/app.js - Frontend JavaScript with jQuery

$(document).ready(function() {

    // Character count
    $('#prompt').on('input', function() {
        $('#charCount').text($(this).val().length);
    });

    // Generator form submission
    $('#generatorForm').on('submit', function(e) {
        e.preventDefault();

        const prompt = $('#prompt').val();
        const aspectRatio = $('input[name="aspectRatio"]:checked').val();
        const csrfToken = $('input[name="csrf_token"]').val();

        if (!prompt || prompt.trim().length < 3) {
            showInlineError('Please enter a detailed prompt (at least 3 characters)');
            return;
        }

        // Add generating class to form
        $('.generator-card').addClass('generating');

        // Disable button and show loading
        const $generateBtn = $('#generateBtn');
        $generateBtn.prop('disabled', true);
        $generateBtn.find('.btn-text').hide();
        $generateBtn.find('.btn-loader').show();

        // Send generation request
        $.ajax({
            url: '/api/generate.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                prompt: prompt.trim(),
                aspect_ratio: aspectRatio,
                csrf_token: csrfToken
            }),
            success: function(data) {
                if (data.success) {
                    // Show waiting message inline
                    showInlineWaiting();

                    // Poll for result
                    pollGenerationStatus(data.generation_id, data.session_token);
                } else {
                    showInlineError(data.error || 'Generation failed');
                    resetForm();
                }
            },
            error: function(xhr) {
                const data = xhr.responseJSON || {};
                if (data.limit_reached) {
                    showContactModal();
                    showInlineError('You have reached your generation limit. Please contact us for more generations.');
                } else {
                    showInlineError(data.error || 'An error occurred');
                }
                resetForm();
            }
        });
    });

    // Poll generation status
    let generationTimer = null;
    let generationStartTime = null;

    function pollGenerationStatus(generationId, sessionToken, attempts = 0) {
        const maxAttempts = 60; // 60 attempts * 2 seconds = 2 minutes max

        // Start timer on first attempt
        if (attempts === 0) {
            generationStartTime = Date.now();
            startGenerationTimer();
        }

        if (attempts >= maxAttempts) {
            stopGenerationTimer();
            showInlineError('Generation timed out. Please try again.');
            resetForm();
            return;
        }

        $.ajax({
            url: '/api/status.php',
            method: 'GET',
            data: {
                id: generationId,
                token: sessionToken
            },
            success: function(data) {
                if (data.status === 'completed' && data.image_url) {
                    // Stop timer and show result inline
                    stopGenerationTimer();
                    showInlineResult(data.image_url);
                } else if (data.status === 'failed') {
                    stopGenerationTimer();
                    showInlineError(data.error_message || 'Generation failed');
                    resetForm();
                } else {
                    // Still processing, poll again
                    setTimeout(function() {
                        pollGenerationStatus(generationId, sessionToken, attempts + 1);
                    }, 2000); // Poll every 2 seconds
                }
            },
            error: function(xhr) {
                stopGenerationTimer();
                const data = xhr.responseJSON || {};
                showInlineError(data.error || 'Failed to check status');
                resetForm();
            }
        });
    }

    function startGenerationTimer() {
        // Clear any existing timer
        if (generationTimer) {
            clearInterval(generationTimer);
        }

        // Update timer every 100ms for smooth counting
        generationTimer = setInterval(function() {
            const elapsed = ((Date.now() - generationStartTime) / 1000).toFixed(2);
            $('#generationTimer').text(elapsed);
        }, 100);
    }

    function stopGenerationTimer() {
        if (generationTimer) {
            clearInterval(generationTimer);
            generationTimer = null;
        }
    }

    // Reset form to normal state
    function resetForm() {
        $('.generator-card').removeClass('generating');
        const $generateBtn = $('#generateBtn');
        $generateBtn.prop('disabled', false);
        $generateBtn.find('.btn-text').show();
        $generateBtn.find('.btn-loader').hide();
    }

    // Show inline waiting status
    function showInlineWaiting() {
        // Remove any existing inline result
        $('.inline-result').remove();

        const html = `
            <div class="inline-result">
                <div class="status-box loading">
                    <div class="status-icon">✨</div>
                    <div class="status-title">Creating Your Image...</div>
                    <div class="status-subtitle">This usually takes around 3 seconds</div>
                    <div class="generation-timer"><span id="generationTimer">0.00</span>s</div>
                </div>
            </div>
        `;
        $('#generatorForm').after(html);
    }

    // Show inline result
    function showInlineResult(imageUrl) {
        // Remove any existing inline result
        $('.inline-result').remove();

        const html = `
            <div class="inline-result">
                <div class="result-image-container">
                    <img src="${escapeHtml(imageUrl)}" alt="Generated image" class="result-image" loading="lazy">
                </div>
                <div class="result-actions">
                    <div style="text-align: center; padding: 1rem; background: rgba(0, 212, 255, 0.05); border-radius: 8px; border: 2px dashed var(--primary-color);">
                        <p style="margin: 0; color: var(--text-primary); font-size: 0.95rem;">
                            <strong>💾 To Save Your Image:</strong><br>
                            Right-click on the image above and select "Save Image As..."
                        </p>
                    </div>
                </div>
            </div>
        `;
        $('#generatorForm').after(html);

        // Reset form state
        resetForm();
    }

    // Show inline error
    function showInlineError(message) {
        // Remove any existing inline result
        $('.inline-result').remove();

        const html = `
            <div class="inline-result">
                <div class="status-box error">
                    <div class="status-icon">⚠️</div>
                    <div class="status-title">Oops! Something went wrong</div>
                    <div class="status-subtitle">${escapeHtml(message)}</div>
                </div>
            </div>
        `;
        $('#generatorForm').after(html);
    }

    // Contact modal
    $('#showContactBtn').on('click', showContactModal);
    $('.modal-close').on('click', hideContactModal);

    $('#contactModal').on('click', function(e) {
        if ($(e.target).is('#contactModal')) {
            hideContactModal();
        }
    });

    function showContactModal() {
        $('#contactModal').addClass('active');
        $('body').css('overflow', 'hidden');
    }

    function hideContactModal() {
        $('#contactModal').removeClass('active');
        $('body').css('overflow', '');
    }

    // Contact form submission
    $('#contactForm').on('submit', function(e) {
        e.preventDefault();

        const $submitBtn = $('#contactSubmitBtn');
        const $successMsg = $('#contactSuccess');

        // Disable button
        $submitBtn.prop('disabled', true).text('Sending...');

        $.ajax({
            url: '/api/contact.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                name: $('#contactName').val(),
                email: $('#contactEmail').val(),
                reason: $('#contactReason').val(),
                message: $('#contactMessage').val(),
                csrf_token: $('input[name="csrf_token"]').val()
            }),
            success: function(data) {
                if (data.success) {
                    // Show success message
                    $('#contactForm').hide();
                    $successMsg.show().text(data.message);

                    // Reset and close after 3 seconds
                    setTimeout(function() {
                        $('#contactForm')[0].reset();
                        $('#contactForm').show();
                        $successMsg.hide();
                        hideContactModal();
                    }, 3000);
                } else {
                    alert(data.error || 'Failed to send message. Please try again.');
                }
            },
            error: function() {
                alert('Network error. Please try again.');
            },
            complete: function() {
                $submitBtn.prop('disabled', false).text('Send Message');
            }
        });
    });

    // Utility function to escape HTML
    function escapeHtml(text) {
        return $('<div>').text(text).html();
    }

    // Smooth scroll for anchor links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        const target = $($(this).attr('href'));
        if (target.length) {
            target[0].scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
