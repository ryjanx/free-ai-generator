<?php
require_once __DIR__ . '/../config.php';

// Get slug from URL
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';

// Load blog post content
$postFile = __DIR__ . '/posts/' . basename($slug) . '.php';
if (!file_exists($postFile)) {
    header('Location: /blog/');
    exit;
}

// Include the post file which sets variables
include $postFile;

// Variables set by post file: $postTitle, $postDescription, $postContent, $postCategory, $postDate, $postReadTime
include __DIR__ . '/../includes/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <div style="max-width: 900px; margin: 0 auto;">
                <div class="blog-post-header">
                    <div class="blog-card-meta" style="justify-content: center;">
                        <span class="blog-card-category"><?php echo htmlspecialchars($postCategory); ?></span>
                        <span><?php echo date('M j, Y', strtotime($postDate)); ?></span>
                        <span><?php echo htmlspecialchars($postReadTime); ?></span>
                    </div>
                    <h1 class="hero-title" style="margin-bottom: 0;"><?php echo htmlspecialchars($postTitle); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Blog Post Content -->
<section class="section">
    <div class="container">
        <article class="blog-post">
            <div class="blog-post-content">
                <?php echo $postContent; ?>
            </div>

            <!-- CTA Section -->
            <div style="background: var(--background-alt); padding: 2rem; border-radius: var(--radius-lg); margin-top: 3rem; text-align: center;">
                <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">Ready to Create Your Own Anime Art?</h3>
                <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">Try our free AI anime generator - no sign-up required</p>
                <a href="/" class="btn btn-primary" style="display: inline-block;">Start Generating Free</a>
            </div>

            <!-- Related Posts -->
            <div style="margin-top: 4rem;">
                <h3 style="font-size: 1.75rem; margin-bottom: 2rem; text-align: center;">More Helpful Guides</h3>
                <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                    <a href="/blog/" class="btn" style="background: var(--background-alt); color: var(--text-primary);">View All Blog Posts</a>
                    <a href="/gallery" class="btn" style="background: var(--background-alt); color: var(--text-primary);">Browse Gallery</a>
                </div>
            </div>
        </article>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
