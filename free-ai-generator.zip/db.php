<?php
require_once __DIR__ . '/config.php';

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            die("Database connection failed. Please try again later.");
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->pdo;
    }

    // Prevent cloning
    private function __clone() {}

    // Prevent unserializing
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

class IPUsageModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getUsage($ip) {
        $stmt = $this->db->prepare("SELECT * FROM ip_usage WHERE ip_address = ? LIMIT 1");
        $stmt->execute([$ip]);
        return $stmt->fetch();
    }

    public function incrementUsage($ip) {
        $existing = $this->getUsage($ip);

        if ($existing) {
            $stmt = $this->db->prepare("UPDATE ip_usage SET generations_used = generations_used + 1, last_used_at = NOW() WHERE ip_address = ?");
            $stmt->execute([$ip]);
        } else {
            $stmt = $this->db->prepare("INSERT INTO ip_usage (ip_address, generations_used) VALUES (?, 1)");
            $stmt->execute([$ip]);
        }
    }

    public function getRemainingGenerations($ip) {
        $usage = $this->getUsage($ip);
        $used = $usage ? $usage['generations_used'] : 0;
        return max(0, MAX_GENERATIONS_PER_IP - $used);
    }

    public function hasReachedLimit($ip) {
        return $this->getRemainingGenerations($ip) <= 0;
    }
}

class GenerationModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($ip, $prompt, $aspectRatio, $falRequestId = null, $sessionToken = null) {
        $stmt = $this->db->prepare(
            "INSERT INTO generations (ip_address, prompt, aspect_ratio, fal_request_id, session_token, status)
             VALUES (?, ?, ?, ?, ?, 'pending')"
        );
        $stmt->execute([$ip, $prompt, $aspectRatio, $falRequestId, $sessionToken]);
        return $this->db->lastInsertId();
    }

    public function updateStatus($id, $status, $imageUrl = null, $errorMessage = null) {
        $stmt = $this->db->prepare(
            "UPDATE generations
             SET status = ?, image_url = ?, error_message = ?, completed_at = NOW()
             WHERE id = ?"
        );
        $stmt->execute([$status, $imageUrl, $errorMessage, $id]);
    }

    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM generations WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function getByIdAndToken($id, $sessionToken) {
        $stmt = $this->db->prepare("SELECT * FROM generations WHERE id = ? AND session_token = ? LIMIT 1");
        $stmt->execute([$id, $sessionToken]);
        return $stmt->fetch();
    }

    public function getByRequestId($requestId) {
        $stmt = $this->db->prepare("SELECT * FROM generations WHERE fal_request_id = ? LIMIT 1");
        $stmt->execute([$requestId]);
        return $stmt->fetch();
    }

    public function getRecentByIP($ip, $limit = 10) {
        $stmt = $this->db->prepare(
            "SELECT * FROM generations
             WHERE ip_address = ? AND status = 'completed'
             ORDER BY created_at DESC
             LIMIT ?"
        );
        $stmt->execute([$ip, $limit]);
        return $stmt->fetchAll();
    }
}

class ContactModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($ip, $email, $name, $message, $reason = 'more_generations') {
        $stmt = $this->db->prepare(
            "INSERT INTO contact_requests (ip_address, email, name, message, reason)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->execute([$ip, $email, $name, $message, $reason]);
        return $this->db->lastInsertId();
    }

    public function getRecentByIP($ip, $hours = 24) {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) as count FROM contact_requests
             WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? HOUR)"
        );
        $stmt->execute([$ip, $hours]);
        $result = $stmt->fetch();
        return $result['count'];
    }
}
